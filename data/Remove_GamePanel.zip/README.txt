Remove GamePanel for Windows 10 1607
http://fdossena.com/?p=w10debotnet/index_1607.frag


How it works:
-Changes permissions to XBOX GamePanel exe and dll files in System32 and SysWOW64
-Deletes them
-Replaces GamePanel.exe in both directories with empty stubs (gp32.exe and gp64.exe)
-Reboots the system


Before you ask, no, the stubs are not bitcoin miners or some other malware, they're literally empty C programs with an empty winmain function, compiled with gcc. You can make them yourself.
