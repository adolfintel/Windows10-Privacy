Remove Compatibility Telemetry for Windows 10 1607
http://fdossena.com/?p=w10debotnet/index_1607.frag


How it works:
-Changes permissions to CompatTelRunner.exe in System32
-Deletes it
-Replaces CompatTelRunner.exe with an empty stub (stub.exe)
-Reboots the system


Before you ask, no, the stubs are not bitcoin miners or some other malware, they're literally empty C programs with an empty winmain function, compiled with gcc. You can make them yourself.
